<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/php_interface/include/sale_payment/billbyepos/init.php");
//require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/esas.epos.bitrix24/install/php_interface/include/sale_payment/esas.epos.bitrix24/init.php");
